document.addEventListener('DOMContentLoaded', function () {
    const samplingRateSlider = document.getElementById('sampling-rate');
    const quantizationLevelsSlider = document.getElementById('quantization-levels');
    const signalTypeSelect = document.getElementById('signal-type');
    const samplingRateValue = document.getElementById('sampling-rate-value');
    const quantizationLevelsValue = document.getElementById('quantization-levels-value');
    const resetBtn = document.getElementById('reset-btn');

    // Update values based on the controls
    samplingRateSlider.addEventListener('input', function () {
        samplingRateValue.textContent = samplingRateSlider.value;
        fetchSignalData();
    });

    quantizationLevelsSlider.addEventListener('input', function () {
        quantizationLevelsValue.textContent = quantizationLevelsSlider.value;
        fetchSignalData();
    });

    signalTypeSelect.addEventListener('change', fetchSignalData);

    // Reset to default values
    resetBtn.addEventListener('click', function () {
        samplingRateSlider.value = 100;
        quantizationLevelsSlider.value = 8;
        signalTypeSelect.value = 'sine';
        samplingRateValue.textContent = 100;
        quantizationLevelsValue.textContent = 8;
        fetchSignalData();
    });

    // Function to fetch signal data from the backend API
    function fetchSignalData() {
        const samplingRate = samplingRateSlider.value;
        const quantizationLevels = quantizationLevelsSlider.value;
        const signalType = signalTypeSelect.value;

        fetch('/api/generate-signal', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                sampling_rate: samplingRate,
                quantization_levels: quantizationLevels,
                signal_type: signalType
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                console.error(data.error);
                alert("Error: " + data.error);
            } else {
                updatePlot(data);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert("Error fetching signal data: " + error.message);
        });
    }

    // Function to update the plot with the received data
    function updatePlot(data) {
        const trace1 = {
            x: data.time,
            y: data.analog_signal,
            mode: 'lines',
            name: 'Analog Signal',
            line: { color: 'blue' },
        };

        const trace2 = {
            x: data.sampled_time,
            y: data.quantized_signal,
            mode: 'markers+lines',
            name: 'Quantized Signal',
            line: { color: 'red' },
            marker: { color: 'red', size: 8 },
        };

        const layout = {
            title: 'Analog vs Digital Signal',
            xaxis: { title: 'Time' },
            yaxis: { 
                title: 'Amplitude',
                range: [-1.2, 1.2]  // Fixed range for better visualization
            },
            showlegend: true,
        };

        Plotly.newPlot('signal-plot', [trace1, trace2], layout);
    }

    // Initialize the plot with default values
    fetchSignalData();
});