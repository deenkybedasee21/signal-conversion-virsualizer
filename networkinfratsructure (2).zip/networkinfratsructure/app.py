from flask import Flask, render_template, request, jsonify
from flask_cors import CORS  # Add this import
import numpy as np

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Route to serve the main webpage
@app.route('/')
def home():
    return render_template('index.html')

# API route to generate signals
@app.route('/api/generate-signal', methods=['POST'])
def generate_signal():
    try:
        data = request.json
        sampling_rate = int(data.get("sampling_rate", 100))
        quantization_levels = int(data.get("quantization_levels", 8))
        signal_type = data.get("signal_type", "sine")

        # Validate inputs
        if sampling_rate < 10 or sampling_rate > 200:
            return jsonify({"error": "Sampling rate must be between 10 and 200"}), 400
        if quantization_levels < 2 or quantization_levels > 16:
            return jsonify({"error": "Quantization levels must be between 2 and 16"}), 400

        # Generate the time values
        t = np.linspace(0, 1, 1000)  # 1 second duration, high resolution

        # Generate the analog signal based on the type
        if signal_type == "sine":
            analog_signal = np.sin(2 * np
                                   
                                   .pi * 5 * t)
        elif signal_type == "square":
            analog_signal = np.sign(np.sin(2 * np.pi * 5 * t))
        elif signal_type == "sawtooth":
            analog_signal = 2 * (t % (1/5)) * 5 - 1
        elif signal_type == "triangular":
            analog_signal = 2 * np.abs(2 * (t % (1/5)) * 5 - 1) - 1
        else:
            return jsonify({"error": "Invalid signal type"}), 400

        # Sample the signal
        sample_points = np.arange(0, len(t), int(1000/sampling_rate))
        sampled_signal = analog_signal[sample_points]

        # Quantize the signal
        quantized_signal = np.round(
            sampled_signal * (quantization_levels/2)
        ) / (quantization_levels/2)

        # Calculate the error signal
        error_signal = sampled_signal - quantized_signal

        # Prepare the response
        response = {
            "time": t.tolist(),
            "analog_signal": analog_signal.tolist(),
            "sampled_time": t[sample_points].tolist(),
            "sampled_signal": sampled_signal.tolist(),
            "quantized_signal": quantized_signal.tolist(),
            "error_signal": error_signal.tolist()
        }
        return jsonify(response)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8000)